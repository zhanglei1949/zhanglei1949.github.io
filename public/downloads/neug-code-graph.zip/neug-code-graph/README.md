# NeuG 代码依赖图示例

验证环境：NeuG 0.2.0，Python 3.11.9，macOS 15.1.1 ARM64。

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python demo.py
```

脚本会生成数据，在临时目录创建数据库，核对数量和查询结果，关闭并重新打开后再次核对，结束时清理临时数据。data/ 是相同输入的 CSV 副本，供手动导入；脚本运行不依赖这些副本。

environment-lock.txt 记录本次验证的完整 Python 依赖版本。脚本和正文代码块已分别运行成功。测试覆盖正常关闭与重新打开，不包含崩溃恢复或性能测试。
