"""A small, reproducible NeuG code-dependency example; synthetic data only."""
import csv
import platform
from importlib.metadata import version
from pathlib import Path
from tempfile import TemporaryDirectory

import neug

FILES = [(1, 'api.py'), (2, 'service.py'), (3, 'storage.py')]
FUNCTIONS = [
    (1, 'handle_request'), (2, 'build_report'), (3, 'load_user'),
    (4, 'load_orders'), (5, 'read_cache'), (6, 'query_db'),
    (7, 'format_response'), (8, 'health_check'),
]
CALLS = [(1, 3), (1, 7), (2, 3), (2, 4), (3, 5), (3, 6), (4, 6)]
DEFINED_IN = [(1, 1), (2, 2), (3, 2), (4, 2), (5, 3), (6, 3), (7, 1), (8, 1)]
SCHEMA = [
    'CREATE NODE TABLE Function(id INT64, name STRING, PRIMARY KEY(id))',
    'CREATE NODE TABLE File(id INT64, path STRING, PRIMARY KEY(id))',
    'CREATE REL TABLE CALLS(FROM Function TO Function)',
    'CREATE REL TABLE DEFINED_IN(FROM Function TO File)',
]
QUERIES = [
    ('direct_callers', """
MATCH (caller:Function)-[:CALLS]->(target:Function {id: 6})
RETURN caller.name AS name ORDER BY name
""", [['load_orders'], ['load_user']]),
    ('upstream_functions', """
MATCH (caller:Function)-[:CALLS*1..3]->(target:Function {id: 6})
RETURN DISTINCT caller.id AS id, caller.name AS name ORDER BY id
""", [[1, 'handle_request'], [2, 'build_report'], [3, 'load_user'], [4, 'load_orders']]),
    ('upstream_files', """
MATCH (caller:Function)-[:CALLS*1..3]->(target:Function {id: 6}),
      (caller)-[:DEFINED_IN]->(file:File)
RETURN DISTINCT file.path AS path ORDER BY path
""", [['api.py'], ['service.py']]),
]


def check_queries(conn):
    for label, query, expected in QUERIES:
        rows = [list(row) for row in conn.execute(query)]
        assert rows == expected, (label, rows, expected)
        print(f'{label}: {rows}')


def main():
    print(f'NeuG {version("neug")} | Python {platform.python_version()} | '
          f'{platform.system()} {platform.machine()}')
    with TemporaryDirectory(prefix='neug-code-graph-') as tmp:
        root = Path(tmp)
        datasets = [
            ('functions.csv', ['id', 'name'], FUNCTIONS),
            ('files.csv', ['id', 'path'], FILES),
            ('calls.csv', ['source', 'target'], CALLS),
            ('defined_in.csv', ['source', 'target'], DEFINED_IN),
        ]
        for name, header, rows in datasets:
            with (root / name).open('w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows(rows)
        db_path = root / 'db'
        db_path.mkdir()
        db = neug.Database(str(db_path))
        conn = db.connect()
        try:
            for query in SCHEMA:
                conn.execute(query)
            for table, filename, extra in [
                ('Function', 'functions.csv', ''),
                ('File', 'files.csv', ''),
                ('CALLS', 'calls.csv', ", from='Function', to='Function'"),
                ('DEFINED_IN', 'defined_in.csv', ", from='Function', to='File'"),
            ]:
                conn.execute(f"COPY {table} FROM '{root / filename}' (header=true, delimiter=','{extra})")
            for label, query, expected in [
                ('functions', 'MATCH (n:Function) RETURN count(n)', 8),
                ('files', 'MATCH (n:File) RETURN count(n)', 3),
                ('calls', 'MATCH (:Function)-[r:CALLS]->(:Function) RETURN count(r)', 7),
                ('definitions', 'MATCH (:Function)-[r:DEFINED_IN]->(:File) RETURN count(r)', 8),
            ]:
                rows = [list(row) for row in conn.execute(query)]
                assert rows == [[expected]], (label, rows)
                print(f'{label}: {rows[0][0]}')
            check_queries(conn)
        finally:
            conn.close()
            db.close()
        db = neug.Database(str(db_path))
        conn = db.connect()
        try:
            check_queries(conn)
            print('Reopen check: passed')
        finally:
            conn.close()
            db.close()


if __name__ == '__main__':
    main()
